^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_kinematics_dynamics
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* none

0.2.0 (2018-03-26)
------------------
* added wholebody module
* changed package.xml to use format v2
* refactoring to release
* Contributors: Pyo, SCH

0.1.1 (2017-10-31)
------------------
* added to check collision
* added test code about collision check
* added direct_control_module
* fixed wrong index of op3 kinematics tree
* changed License from BSD to Apache 2.0
* changed collision range
* Contributors: Kayman

0.1.0 (2017-10-27)
------------------
* added walking_module use op3_kinematics_dynamics(for IK)
* applied new leg structure to the walking_module and the kinematicsdynamics
* applied ROS C++ Coding Style
* applied ROBOTIS framework
* Contributors: Kayman
