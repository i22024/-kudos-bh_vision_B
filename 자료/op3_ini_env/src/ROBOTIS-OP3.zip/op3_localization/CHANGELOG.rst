^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_localization
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* none

0.2.0 (2018-03-26)
------------------
* first release of op3_localization package
* added wholebody module update & localization
* added online walking module
* changed package.xml to use format v2
* refactoring to release
* Contributors: Kayman, SCH, Pyo
