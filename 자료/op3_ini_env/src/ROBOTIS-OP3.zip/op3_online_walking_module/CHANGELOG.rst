^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_online_walking_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* modified preview_response to fix operator matching bug on i386 machine
* Contributors: SCH

0.2.0 (2018-03-26)
------------------
* first release of op3_online_walking_module package
* added LICENSE
* deleted op3_optimization
* deleted debug print
* Contributors: Kayman, Pyo, SCH
