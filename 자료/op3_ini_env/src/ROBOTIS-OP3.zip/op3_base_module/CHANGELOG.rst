^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_base_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* none

0.2.0 (2018-03-26)
------------------
* changed method to setting module(msg -> srv)
* fixed a bug to jump to init pose
* fixed a bug in head_control_module that wrong init vel or accel is set for generating trajectory in middle of moving
* changed a method of setting module in base_module
* added C++11 build option
* changed package.xml to use format v2
* refactoring to release
* Contributors: Kayman, Pyo

0.1.1 (2017-10-31)
------------------
* fixed missing dependence
* Changed License from BSD to Apache 2.0
* Contributors: Kayman

0.1.0 (2017-10-27)
------------------
* added the function of recovery after reset
* added Tools
* changed setting for walking and dxl
* change directory structure
* change package name : op2 -> op3
* splited the repository of ROBOTIS-OP3
* cleaned up the code
* Contributors: Kayman
