^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package open_cr_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* none

0.2.0 (2018-03-26)
------------------
* refactoring to release
* changed package.xml to use format v2
* Contributors: Pyo

0.1.1 (2017-10-31)
------------------
* fixed missing dependence
* changed License from BSD to Apache 2.0
* Contributors: Kayman

0.1.0 (2017-10-27)
------------------
* added new metapackage for ROBOTIS OP3
* added the function of recovery after reset
* added function of reset dxl power
* Contributors: Kayman
