^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_walking_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* none

0.2.0 (2018-03-26)
------------------
* added debug print
* changed package.xml to use format v2
* refactoring to release
* Contributors: Kayman, Pyo

0.1.1 (2017-10-31)
------------------
* added missing package in find_package()
* added op3_walking_module_msgs in find_package() function
* fixed missing dependence
* fixed action_module bug
* changed License from BSD to Apache 2.0
* Merge branch 'feature_direct_control' of https://github.com/ROBOTIS-GIT/ROBOTIS-OP3 into feature_direct_control
* Contributors: Kayman, Yoshimaru Tanaka, Pyo

0.1.0 (2017-10-27)
------------------
* added the function of recovery after reset
* deleted Hardware materials
* modified parameter for release
* changed setting for walking and dxl
* Contributors: Kayman
