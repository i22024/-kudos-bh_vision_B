^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_action_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* none

0.2.0 (2018-03-26)
------------------
* changed package.xml to use format v2
* refactoring to release
* Contributors: Kayman, SCH, Pyo

0.1.1 (2017-10-31)
------------------
* fixed missing dependence
* fixed action_module bug
* changed License from BSD to Apache 2.0
* Contributors: Kayman

0.1.0 (2017-10-27)
------------------
* added the function of recovery after reset
* added action, modified dxl init file
* added Tools
* fixed actions that move unexpected
* modified action file
* modified parameter for release
* cleanup the code
* splited the repository of ROBOTIS-OP3
* change package name : op2 -> op3
* Contributors: Kayman
