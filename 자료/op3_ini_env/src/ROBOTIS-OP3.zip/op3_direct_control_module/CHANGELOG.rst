^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_direct_control_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* none

0.2.0 (2018-03-26)
------------------
* refactoring to release
* changed package.xml to use format v2
* Contributors: Pyo

0.1.1 (2017-10-31)
------------------
* added to check collision
* added test code about collision check
* added direct_control_module
* added debuging code
* applied test code for check the collision
* fixed missing dependence
* modified checking collision in direct_control_module
* changed License from BSD to Apache 2.0
* changed some parameter of direct_control_module
* changed debug print
* changed collision range
* Contributors: Kayman
