^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_balance_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.1 (2018-03-26)
------------------
* none

0.2.0 (2018-03-26)
------------------
* first release of op3_balance_control package
* added wholebody module
* added C++11 build option
* changed package.xml to use format v2
* refactoring to release
* Contributors: Kayman, SCH, Pyo
