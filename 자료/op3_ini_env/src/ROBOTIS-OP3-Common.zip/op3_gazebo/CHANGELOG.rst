^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2018-03-26)
------------------
* changed package names and paths related for OP Series
* Contributors: Pyo

0.1.0 (2018-03-26)
------------------
* added camera and imu for gazebo 
* added gazebo simulation 
* refactoring to release
* Contributors: SCH, Pyo
