^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2018-03-26)
------------------
* changed package names and paths related for OP Series
* Contributors: Pyo

0.1.0 (2018-03-26)
------------------
* added robotis-op3 robot description
* modified the launch file to view on RViz
* modified for walking upgrade
* refactoring to release
* Contributors: SCH, Kayman, Pyo
