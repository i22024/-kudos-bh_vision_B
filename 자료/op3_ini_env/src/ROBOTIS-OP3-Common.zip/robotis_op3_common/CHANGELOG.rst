^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robotis_op3_common
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2018-03-26)
------------------
* changed package names and paths related for OP Series
* Contributors: Pyo

0.1.0 (2018-03-26)
------------------
* added metapackage
* refactoring to release
* Contributors: Pyo
